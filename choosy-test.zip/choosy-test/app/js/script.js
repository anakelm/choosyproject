console.log("hello");

function myFunction() {
    var x = document.getElementById('toggle-on-click');
    if (x.style.display === "none") {
      x.style.display = "block";
    } else {
      x.style.display = "none";
    }
}